package com.byjus.stackoverflow.entities;

public interface Badge {
    
}
