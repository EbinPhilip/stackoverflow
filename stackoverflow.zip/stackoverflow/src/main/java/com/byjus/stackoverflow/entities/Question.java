package com.byjus.stackoverflow.entities;

import java.util.Map;
import java.util.UUID;

import lombok.Getter;

@Getter
public class Question implements UpVotable, Flaggable {
    
    private UUID id;

    private UUID userId;

    private String content;

    private QuestionStatus status;

    private int upVotes;

    Map<UUID, Comment> comments;
    Map<UUID, Answers> answers;

    Set<String> tags;

    public void upVote()
    {
        upVotes++;
    }

    public int getUpVotes()
    {
        return upVotes;
    }
}
