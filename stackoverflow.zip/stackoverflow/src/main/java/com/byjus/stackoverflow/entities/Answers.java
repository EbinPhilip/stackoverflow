package com.byjus.stackoverflow.entities;

import java.util.UUID;

public class Answers implements UpVotable {

    private UUID id;

    private UUID parentId;

    private UUID userId;

    private int upVotes;

    public void upVote()
    {
        upVotes++;
    }

    public int getUpVotes()
    {
        return upVotes;
    }
}
