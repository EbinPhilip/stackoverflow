package com.byjus.stackoverflow.entities;

public class User implements UserInterface{
    
}
