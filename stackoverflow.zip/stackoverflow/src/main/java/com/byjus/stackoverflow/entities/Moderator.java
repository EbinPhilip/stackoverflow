package com.byjus.stackoverflow.entities;

public class Moderator implements UserInterface{
    
}
