package com.byjus.stackoverflow.entities;

import java.util.UUID;

import lombok.Getter;

@Getter
public class Comment implements UpVotable {

    public enum Type {
        question,
        answer
    }

    private UUID id;

    private UUID parentId;

    private UUID userId;

    private String content;

    private int upVotes;

    public void upVote()
    {
        upVotes++;
    }

    public int getUpVotes()
    {
        return upVotes;
    }
}
