package com.byjus.stackoverflow.entities;

public interface UpVotable {

    public void upVote();
    public int getUpVotes();
}
